defmodule Liveapp.Mailer do
  use Swoosh.Mailer, otp_app: :liveapp
end
