defmodule LiveappWeb.PageHTML do
  use LiveappWeb, :html

  embed_templates "page_html/*"
end
