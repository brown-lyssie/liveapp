defmodule LiveappWeb.Layouts do
  use LiveappWeb, :html

  embed_templates "layouts/*"
end
